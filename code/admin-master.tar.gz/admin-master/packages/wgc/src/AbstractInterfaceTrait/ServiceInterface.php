<?php


namespace WGCYunPay\AbstractInterfaceTrait;


interface ServiceInterface
{
    function execute();
}
