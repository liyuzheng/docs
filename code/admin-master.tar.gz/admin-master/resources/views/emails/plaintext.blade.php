<!DOCTYPE doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml">
<head>
    <title>
        Discount Light
    </title>
    <!--[if !mso]><!-- -->
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <!--<![endif]-->
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width,initial-scale=1" name="viewport">
</head>
<body>
    <h4>{{ $txt }}</h4>
</body>
</html>
