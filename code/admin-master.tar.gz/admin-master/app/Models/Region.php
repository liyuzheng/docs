<?php


namespace App\Models;


class Region extends BaseModel
{
    protected $table = 'region';
}