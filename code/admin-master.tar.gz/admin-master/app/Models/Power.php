<?php


namespace App\Models;


class Power extends BaseModel
{
    protected $table = 'power';
}