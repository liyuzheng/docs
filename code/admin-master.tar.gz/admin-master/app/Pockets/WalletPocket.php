<?php


namespace App\Pockets;


use App\Foundation\Modules\Pocket\BasePocket;

class WalletPocket extends BasePocket
{

}
