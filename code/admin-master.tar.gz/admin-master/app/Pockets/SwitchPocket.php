<?php


namespace App\Pockets;


use App\Foundation\Modules\Pocket\BasePocket;

class SwitchPocket extends BasePocket
{

}
