<?php


namespace App\Pockets;


use App\Foundation\Modules\Pocket\BasePocket;

class PrizePocket extends BasePocket
{
    
}
