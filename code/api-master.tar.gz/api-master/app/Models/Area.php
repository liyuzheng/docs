<?php


namespace App\Models;

/**
 * 经纬度地区表
 * Class Area
 * @package App\Models
 */
class Area extends BaseModel
{
    protected $table = 'area';
}
