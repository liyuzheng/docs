<?php
/**
 * Created by PhpStorm.
 * User: ailuoy
 * Date: 2019/3/28
 * Time: 上午12:15
 */

namespace App\Foundation\Modules\Response;


class BusinessCode
{
    //检查到用户不在房间,客户端弹框,并返回上一页
    const ROOM_USER_EXISTS_FALSE_CLIENT_BACK = 4039901;
}