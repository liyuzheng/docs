<?php


namespace App\Pockets;


use App\Foundation\Modules\Pocket\BasePocket;

class UserJobPocket extends BasePocket
{

}
