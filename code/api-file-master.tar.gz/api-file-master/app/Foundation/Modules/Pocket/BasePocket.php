<?php
/**
 * Created by PhpStorm.
 * User: ailuoy
 * Date: 2019/3/5
 * Time: 上午9:53
 */

namespace App\Foundation\Modules\Pocket;


class BasePocket implements PocketInterface
{

}