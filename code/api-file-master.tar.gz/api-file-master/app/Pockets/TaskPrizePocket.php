<?php


namespace App\Pockets;


use App\Foundation\Modules\Pocket\BasePocket;

class TaskPrizePocket extends BasePocket
{

}
