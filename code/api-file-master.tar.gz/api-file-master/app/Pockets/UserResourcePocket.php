<?php


namespace App\Pockets;


use App\Foundation\Modules\Pocket\BasePocket;

class UserResourcePocket extends BasePocket
{

}
