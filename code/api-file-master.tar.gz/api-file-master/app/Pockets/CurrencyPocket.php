<?php


namespace App\Pockets;


use App\Foundation\Modules\Pocket\BasePocket;

class CurrencyPocket extends BasePocket
{

}
